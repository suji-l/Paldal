package com.test.place;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;
import com.test.place.writeReview;


public class seoulGangnamPlayPlace {

	
	//명소 데이터를 "지역"으로 필터링하고 목록 출력
	public void filterSeoul(List<List<PlaceBasic>> list) throws Exception {
		int count = 1;
		for (int i = 0; i < list.get(0).size(); i++) {
			String tmp = list.get(0).get(i).getAddress();
			String gangnamtemp = list.get(0).get(i).getName();
			
				if (tmp.contains("강남구")) {
					System.out.printf("[순서]\t[장소명]\t\t[위치]\t\t\t\t\t[별점]\n");
					System.out.print(count + ".        \t");
					System.out.print(gangnamtemp + "\t\t ");					
					System.out.print(tmp + "\t");
					
					System.out.println("4.7"+"\n");
					count++;
				
			}

		}
		Scanner scan = new Scanner(System.in);
		System.out.println("1. 리뷰");
		System.out.print("입력 : ");
		
		String selnum = scan.nextLine();
		switch (selnum) {
		case "1":
			System.out.println();
			filterpaldal(list);
			System.out.println("==============리뷰==============");
			paldalReview();
			System.out.print("리뷰 작성 : ");			
			writeReview wrR= new writeReview();
			wrR.writeReviewNow();
			break;
		case "2":
			System.out.println();
			filterpaldal(list);
			System.out.println("==============리뷰==============");
			paldalReview();
			
			break;
		
	}
	}


	//리뷰에서 해당장소 리뷰만 불러오기
	private void paldalReview() {
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader("D:\\resource\\Review.dat"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String line = null;

		try {
			int i = 1;
			while ((line = reader.readLine()) != null) {
				
				if (line.contains("팔달월드")) {
					System.out.print(i + "■");
				System.out.printf("%s\r\n", line);
				i++;
				}
				
				
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	private void filterpaldal(List<List<PlaceBasic>> list) throws Exception {
		for (int i = 0; i < list.get(0).size(); i++) {
			String temp = list.get(0).get(i).getName();
			String gangnamtemp = list.get(0).get(i).getDescription();
			
				if (temp.contains("팔달월드")) {
															
					System.out.print(gangnamtemp);
					System.out.println();
				}
		}
				
										
				
			}
				
	//장소 설명 불러오기
	//겟인포 플레이스에 옮겨야한다
	private void paldalworld() {
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader("D:\\resource\\paldal.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String line = null;

		try {
			while ((line = reader.readLine()) != null) {
				System.out.printf("%s\r\n", line);

			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
