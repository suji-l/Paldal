package com.test.place;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.test.member.memberMain;
import com.test.reservation.ReservationBasic;
import com.test.review.ReviewBasic;

public class GetInfoOfPlaceMain {
	Scanner scan = new Scanner(System.in);
	boolean loginStatus;

	public void getListOfLocal(List<PlaceBasic> allPlaceThatSelectedbyUser) {
		String placeName = "";
		while (true) {
			int i = 1;
			for (PlaceBasic place : allPlaceThatSelectedbyUser) {
				System.out.printf("\t\t\t%d. %s\n", i, place.getName());
			}

			System.out.println("\t\t\t0. 뒤로가기");
			System.out.println("\t\t\t번호 입력 : ");

			// 장소 번호 입력
			String selectNum = scan.nextLine();
			// 선택된 장소의 placeName과 지역이름 넣어줌
			if (Integer.parseInt(selectNum) > 0 && Integer.parseInt(selectNum) < allPlaceThatSelectedbyUser.size()) {
				getInfoOfPlace(allPlaceThatSelectedbyUser.get(Integer.parseInt(selectNum) - 1));
			} else if (selectNum.equals("0")) {
				break;
			}
		}

	}

	private void getInfoOfPlace(PlaceBasic selectedPlace) {
		while (true) {
			// 회원 케이스
			if (loginStatus) {
				// 해당 지역의 가게 정보를 갖고있는 place객체 생성
				// 고유번호 이름 설명 주소 별점 체류시간 카테고리 예약가능여부 가격

				System.out.println("해당 장소의 정보 출력하기");

				selectedPlace.getName(); // 이름, 설명 등등
				selectedPlace.getDescription();

				// 해당 장소의 리뷰를 보여주기 위해 review 선언
				ReviewBasic review = new ReviewBasic(selectedPlace);

				System.out.println("1. 예약하기");
				System.out.println("2. 리뷰쓰기");
				System.out.println("3. 리뷰 더보기");
				System.out.println("0. 뒤로가기");

				String selectNum = scan.nextLine();
				// 예약하기, 리뷰쓰기, 리뷰 더보기
				if (selectNum.equals("1") && selectedPlace.getReservationPosibility() == true) {
					ReservationBasic reservation = new ReservationBasic();
					reservation.makeReservation(selectedPlace);
				} else if (selectNum.equals("1") && selectedPlace.getReservationPosibility() == false) {
					System.out.println("\t\t\t죄송합니다 예약이 불가능한 지점입니다.");
				}

				else if (selectNum.equals("2")) {
					memberMain.getUserId();
					System.out.println("리뷰쓰기 메소드 실행");

					review.writeReview(selectedPlace);

				} else if (selectNum.equals("3")) {
					review.moreReview(selectedPlace);

				} else if (selectNum.equals("0")) {
					System.out.println("리스트로 돌아갑니다.");
					break;
				}
				// 비회원
			} else if (!loginStatus) {

				System.out.println("해당 장소의 정보 출력하기");
				selectedPlace.getName(); // 이름, 설명 등등
				selectedPlace.getDescription();

				// 해당 장소의 리뷰를 보여주기 위해 review 선언
				System.out.println("1. 리뷰 더보기");
				System.out.println("0. 뒤로가기");

				String selectNum = scan.nextLine();
				// 예약하기, 리뷰쓰기, 리뷰 더보기
				if (selectNum.equals("1")) {
					ReservationBasic reservation = new ReservationBasic();
					reservation.makeReservation(selectedPlace);
				} else if (selectNum.equals("0")) {
					System.out.println("\t\t\t리스트로 돌아갑니다.");
					break;
				} else {
					System.out.println("\t\t\t번호를 다시 입력해주세요.");
				}
			}

		}

	}

	public static void weather() { // 매개변수 : 날씨 데이터
		// 날씨 더미데이터를 받아서 날씨 출력

		System.out.println("날씨 출력");
	}

	public boolean isLoginStatus() {
		return loginStatus;
	}

	public void setLoginStatus(boolean loginStatus) {
		this.loginStatus = loginStatus;
	}
}
