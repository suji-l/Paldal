package com.test.place;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class placeSelectMain {
	Scanner scan = new Scanner(System.in);
	String totalLocal = "";
	boolean flag = false;

	public String selectLocal() {
		while (true) {
			if (totalLocal.equals("")) {
				// 한반도 사진 출력
				System.out.println("한반도 출력");

				// 지역 번호 출력
				System.out.println("\t\t\t====================");
				System.out.println("\t\t\t1. 서울특별시");
				System.out.println("\t\t\t2. 인천광역시");
				System.out.println("\t\t\t3. 대전광역시");
				System.out.println("\t\t\t4. 대구광역시");
				System.out.println("\t\t\t5. 울산광역시");
				System.out.println("\t\t\t6. 부산광역시");
				System.out.println("\t\t\t7. 광주광역시");
				System.out.println("\t\t\t8. 제주도");
				System.out.println("\t\t\t9. 경기도");
				System.out.println("\t\t\t10. 강원도");
				System.out.println("\t\t\t11. 충청도");
				System.out.println("\t\t\t12. 전라도");
				System.out.println("\t\t\t13. 경상도");
				System.out.println("\t\t\t====================");
				System.out.println("\t\t\t0: 뒤로 가기");
				// 사용자에게 번호 입력받음
				System.out.println("\t\t\t번호 입력:");
				String selectNum = scan.nextLine();

				if (selectNum.equals("1")) {
					totalLocal = "서울특별시";
				} else if (selectNum.equals("2")) {
					totalLocal = "경기도";
				}
				// 지역번호들 else if문으로 추가하기
				// 지역들 번호 쭉 입력해주세요
				else if (selectNum.equals("0")) {
					break;
				}
				System.out.printf("\t\t\t선택한 지역 : %s\n", totalLocal);
			}
			selectLocal2(totalLocal);
			if (flag) {
				System.out.printf("\t\t\t최종 선택 지역: %s\n", totalLocal);
				break;
			}
		}
		return totalLocal;
	}

	private void selectLocal2(String local) {
		
		// 더미 데이터를 불러와서 더미 데이터에서 local을 포함하는 데이터 가져오기
		while (true) {
			/*
			 * 멤버 변수로 선언된 totalPlace에는 selectLocal1에서 할당한 특별시,도 가 들어가있을테니 totalPlace를 포함하는
			 * 구,군을 꺼내오면 됩니다.
			 */
			System.out.println("셀렉로컬2");
			HashMap<String,ArrayList<String>> totalLocalMap = makeLocalList();
			List<String> local2List = new ArrayList<String>();
			System.out.println(totalLocalMap);
			for(String local1 : totalLocalMap.keySet()) {
				if(local1.equals(local)) {
					local2List = totalLocalMap.get(local1);
					System.out.println("\t\t\t====================");
					int i=1;
					for(String valueName : local2List) {
						System.out.printf("\t\t\t%d. %s\n",i,valueName);
						i++;
					}
					System.out.println("\t\t\t====================");
					System.out.println("\t\t\t번호 입력 : ");
				}
				
			}
			

			String selectNum = scan.nextLine();
			if (Integer.parseInt(selectNum) > 0 && Integer.parseInt(selectNum) < local2List.size()) {
				totalLocal += local2List.get(Integer.parseInt(selectNum)-1);
				flag = true;
				break;
			} else if (selectNum.equals("0")) {
				totalLocal = "";
				break;
			} else {
				System.out.println("\t\t\t올바른 번호를 입력해주세요.");
			}
		}
	}
	public HashMap<String,ArrayList<String>> makeLocalList(){
        HashMap<String, ArrayList<String>> localList = new HashMap<String, ArrayList<String>>();
        
        ArrayList<String> seoul = new ArrayList<String>();
        
        seoul.add("강남구"); seoul.add("강동구"); seoul.add("강북구");
        seoul.add("강서구"); seoul.add("관악구"); seoul.add("광진구");
        seoul.add("구로구"); seoul.add("노원구"); seoul.add("도봉구");
        seoul.add("동대문구"); seoul.add("동작구"); seoul.add("마포구");
        seoul.add("서대문구"); seoul.add("송파구"); seoul.add("도봉구");
        seoul.add("서초구"); seoul.add("양천구"); seoul.add("은평구");
        seoul.add("성동구"); seoul.add("영등포구"); seoul.add("종로구");
        seoul.add("성북구"); seoul.add("용산구"); seoul.add("중구구");
        
        
        ArrayList<String> Kyonggi = new ArrayList<String>();
        Kyonggi.add("수원시"); Kyonggi.add("안산시"); Kyonggi.add("군포시"); Kyonggi.add("안성시");
        Kyonggi.add("성남시"); Kyonggi.add("과천시"); Kyonggi.add("부천시"); Kyonggi.add("오산시");
        Kyonggi.add("용인시"); Kyonggi.add("광명시"); Kyonggi.add("시흥시"); Kyonggi.add("의왕시");
        Kyonggi.add("안양시"); Kyonggi.add("광주시"); Kyonggi.add("김포시"); Kyonggi.add("이천시");
        Kyonggi.add("평택시"); Kyonggi.add("하남시"); Kyonggi.add("화성시"); Kyonggi.add("여주시");
   

        localList.put("서울특별시", seoul);
        localList.put("경기도", Kyonggi);
        

        
        return localList;
     };
}
