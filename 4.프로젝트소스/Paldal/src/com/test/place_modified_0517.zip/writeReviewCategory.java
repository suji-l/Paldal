package com.test.place;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class writeReviewCategory {
	
	private List<List<writeReviewBasic>> list;
	
	public List<List<writeReviewBasic>> filterCategory() throws Exception {
		list = new ArrayList<List<writeReviewBasic>>();
		
		List<writeReviewBasic> paldalmun =  new ArrayList<writeReviewBasic>();
		List<writeReviewBasic> paldalWorld = new ArrayList<writeReviewBasic>();
		List<writeReviewBasic> gyungbok = new ArrayList<writeReviewBasic>();
		
		File file = new File("D:\\resource\\Review.dat");
		BufferedReader reader = new BufferedReader(new FileReader(file));
		String line = null;
		int i = 0;
		while ((line = reader.readLine()) != null) {

			
			String[] temp = line.split("■");
			
			writeReviewBasic wRB = new writeReviewBasic(temp[0], temp[1], temp[2], temp[3],temp[4]);
			
			
			
			switch (wRB.getReviewPlace().split("")[0]) {
			case "팔달문":
				paldalmun.add(wRB);
				break;
			case "팔달월드":
				paldalWorld.add(wRB);
				break;
			case "경복궁":
				gyungbok.add(wRB);
				break;
			} 
		
			
	}
		list.add(paldalWorld);
		System.out.println(paldalWorld);
	
		return list;
}
}
