package com.test.place;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

public class writeReview {
	
	public void writeReviewNow() throws Exception {
		
		File file = new File("D:\\resource\\Review.dat");
	     FileWriter writer = new FileWriter(file,true);
		Scanner scan = new Scanner(System.in);
		String temp = scan.nextLine();
		writer.write("name"+"■");
		writer.write( "팔달월드"+"■");
		writer.write(temp + "■");
		Calendar cal = Calendar.getInstance();		
		SimpleDateFormat time = new SimpleDateFormat("yyyy.MM.dd.HH.mm");
		String writetime = time.format(cal.getTime());
		writer.write(writetime+ "■");
		System.out.print("점수 : ");
		writer.write(scan.nextLine()+"\n");
		writer.close();
		
	}
		
}
	
	
